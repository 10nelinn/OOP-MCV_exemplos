def mostrar_produto(produto):
    print(f"Produto: {produto.nome}")
    print(f"Preço: R$ {produto.preco:.2f}")