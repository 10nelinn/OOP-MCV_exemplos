class Produto:
    def __init__(self, nome, preco):
        self.nome = nome
        self.preco = preco