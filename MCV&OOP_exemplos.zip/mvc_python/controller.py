from model import Produto
from view import mostrar_produto

def exibir():
    produto = Produto("Smartphone", 2499.90)
    mostrar_produto(produto)