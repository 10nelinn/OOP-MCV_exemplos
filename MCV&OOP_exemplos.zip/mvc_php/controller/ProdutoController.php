<?php
require_once 'model/Produto.php';

class ProdutoController {
    public function mostrarProduto() {
        $produto = new Produto("Notebook", 3500);
        include 'view/produtoView.php';
    }
}
?>