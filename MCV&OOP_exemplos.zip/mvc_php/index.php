<?php
require_once 'controller/ProdutoController.php';

$controller = new ProdutoController();
$controller->mostrarProduto();
?>