<!DOCTYPE html>
<html>
<head><title>Produto</title></head>
<body>
    <h1><?php echo $produto->nome; ?></h1>
    <p>Preço: R$ <?php echo $produto->preco; ?></p>
</body>
</html>