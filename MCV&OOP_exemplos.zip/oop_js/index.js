class Usuario {
    constructor(nome) {
        this.nome = nome;
    }

    cumprimentar() {
        console.log(`Olá, eu sou ${this.nome}`);
    }
}

class Admin extends Usuario {
    cumprimentar() {
        console.log(`Admin ${this.nome} logado.`);
    }
}

const user1 = new Usuario("João");
const admin1 = new Admin("Maria");

user1.cumprimentar();
admin1.cumprimentar();