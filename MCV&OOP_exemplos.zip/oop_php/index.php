<?php
class Animal {
    public function fazerSom() {
        echo "Som genérico<br>";
    }
}

class Cachorro extends Animal {
    public function fazerSom() {
        echo "Latido!<br>";
    }
}

class Gato extends Animal {
    public function fazerSom() {
        echo "Miau!<br>";
    }
}

$animais = [new Cachorro(), new Gato()];
foreach ($animais as $animal) {
    $animal->fazerSom();
}
?>